module FunnyPost {
	requires javafx.controls;
	requires java.sql;
	requires javafx.fxml;
	requires java.json;
	
	opens application to javafx.graphics, javafx.fxml;
}
