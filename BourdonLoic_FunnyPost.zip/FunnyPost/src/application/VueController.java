package application;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import model.derby;

import org.json.JSONArray;
import org.json.JSONObject;


public class VueController  {
	
	@FXML
	private Button bdd;
	
	@FXML
	private Button init;
	
	@FXML
	private Label reveal;
	
	public void clickMe(ActionEvent e) {

		try {
			reveal.setText(derby.dimitri());
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
	}
	public void clickInit(ActionEvent e) throws ClassNotFoundException, SQLException {

    	System.out.println("Cliqué init");
    	reveal.setText(derby.getPost());
        
	} 
	
	
	}


