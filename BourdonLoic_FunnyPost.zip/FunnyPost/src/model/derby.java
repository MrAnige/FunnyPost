package model;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONArray;
import org.json.JSONObject;

	public class derby {
		private static String URL = "jdbc:derby:cciDB;create=true";
		private static String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
		private static String USERNAME = "";
		private static String PASSWORD = "";
		private static String LOGIN = "";
		private static String PWD = "";
		private static String s="";
		
		
		//Exo 1 : creation table + insert
		public derby() throws ClassNotFoundException {
			try {
				Class.forName("org.apache.derby.jdbc.ClientDriver");
				Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
				
			      String createTableSQL = "CREATE TABLE poste (userId INTEGER,id INTEGER PRIMARY KEY, title VARCHAR(255), body VARCHAR(1023))";
			      PreparedStatement createTableStmt = conn.prepareStatement(createTableSQL);
			      createTableStmt.executeUpdate();

			  /*    String insertSQL = "INSERT INTO eleve (id, nom, prenom) VALUES (?, ?, ?)";
			      PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
			      insertStmt.setInt(1, 1);
			      insertStmt.setString(2, "Dupont");
			      insertStmt.setString(3, "Jean");
			      insertStmt.executeUpdate();

			      insertStmt.setInt(1, 2);
			      insertStmt.setString(2, "Durand");
			      insertStmt.setString(3, "Marie");
			      insertStmt.executeUpdate();*/

			      System.out.println("Enregistrements ajoutés avec succès !");
			      
			      String selectSQL = "SELECT * FROM poste";
			      Statement selectStmt = conn.createStatement();
			      ResultSet rs = selectStmt.executeQuery(selectSQL);

			      while (rs.next()) {
			    	int userId = rs.getInt("userId");
			        int id = rs.getInt("id");
			        String title = rs.getString("title");
			        String body = rs.getString("body");
			        System.out.println("userId : " + userId + "id : " + id + ", title : " + title + ", body : " + body);
			      }
			      
			      rs.close();
			      selectStmt.close();
			     /* insertStmt.close();
			      createTableStmt.close();*/
			      conn.close();
			} catch (SQLException e) {
			      e.printStackTrace();
		    }
		}
		
		//Connexion BDD ainsi qu'à la table pour vérifier la connexion
		public void derbyInsert(int idmsg, String title, String body) throws ClassNotFoundException {
			try {
				Class.forName("org.apache.derby.jdbc.ClientDriver");
				Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
				
			      String insertSQL = "INSERT INTO poste (userId,id, title, body) VALUES (?, ?, ?, ?)";
			      PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
			      for(int i=0;i<idmsg;i++) {
			      insertStmt.setInt(1, idmsg);
			      insertStmt.setString(2, title);
			      insertStmt.setString(3, body);
			      insertStmt.executeUpdate();
			      }

			      System.out.println("Enregistrements ajoutés avec succès !");
			      
			      String selectSQL = "SELECT * FROM poste";
			      Statement selectStmt = conn.createStatement();
			      ResultSet rs = selectStmt.executeQuery(selectSQL);

			      while (rs.next()) {
			        int id = rs.getInt("id");
			        String nom = rs.getString("nom");
			        String prenom = rs.getString("prenom");
			        System.out.println("id : " + id + ", nom : " + nom + ", prénom : " + prenom);
			      }
			      
			      rs.close();
			      selectStmt.close();
			     /* insertStmt.close();
			      createTableStmt.close();*/
			      conn.close();
			} catch (SQLException e) {
			      e.printStackTrace();
		    }
		}
		public void ConnectBDD() {
	        try {
	            Class.forName(DRIVER);
	            Connection cn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	            System.out.println("Connexion à la base de données");
	           /* Statement st = cn.createStatement();
	            st.execute("create table eleve (code int, nom varchar(20), prenom varchar(20))");
	            st.executeUpdate("INSERT INTO eleve VALUES (1, 'DURAND','Jacques')");
	            st.executeUpdate("INSERT INTO eleve VALUES (2, 'DUPOND','Daniel')");*/
	        }catch (ClassNotFoundException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }

	            catch (SQLException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	        }
		
		//Exo1
		public static String dimitri() throws ClassNotFoundException,SQLException {
				String s = "";
				Class.forName("org.apache.derby.jdbc.ClientDriver");
				Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
				System.out.println("Connection à la base de données");
				
				 String selectSQL = "SELECT * FROM poste";
			      Statement selectStmt = conn.createStatement();
			      ResultSet rs = selectStmt.executeQuery(selectSQL);
			      while (rs.next()) {
				        bddchamps line = new bddchamps(rs.getInt("userId"),rs.getInt("id"), rs.getString("title"), rs.getString("body"));
				        s = s + line.postText() + "\n";
				      //  System.out.println("userId :"+userId+"id : " + id + ", title : " + title + ", body : " + body);
				      }
			      
			      rs.close();
			      selectStmt.close();
			      conn.close();
			      
			      return s;
			}
		
		//Exo2
		public static String getPost() throws ClassNotFoundException,SQLException{
		 try {
	            // Envoyer la requête GET
				Class.forName("org.apache.derby.jdbc.ClientDriver");
				Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	            URL url = new URL("https://jsonplaceholder.typicode.com/posts");
	            HttpURLConnection con = (HttpURLConnection) url.openConnection();
	            con.setRequestMethod("GET");
	            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

	            // Lire la réponse
	            String line;
	            StringBuilder response = new StringBuilder();
	            while ((line = reader.readLine()) != null) {
	            	response.append(line);
	            }
	            
	            // *ENLEVER COMMENTAIRE SI LA TABLE EST VIDE * //
	            
	           /* JSONArray jsonArray = new JSONArray(response.toString());
	            
	        	String insertSQL = "INSERT INTO poste (userId, id, title, body) VALUES (?, ?, ?, ?)";
			    PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
	            for (int i = 0; i < jsonArray.length(); i++) {
	                JSONObject jsonObject = jsonArray.getJSONObject(i);
	                insertStmt.setInt(1,(int) jsonObject.get("userId"));
	                insertStmt.setInt(2,(int) jsonObject.get("id"));
				    insertStmt.setString(3, jsonObject.get("title").toString());
				    insertStmt.setString(4, jsonObject.get("body").toString());
				    insertStmt.executeUpdate();
	                System.out.println(jsonObject);
	                }*/
	              String selectSQL = "SELECT * FROM poste";
			      Statement selectStmt = conn.createStatement();
			      ResultSet rs = selectStmt.executeQuery(selectSQL);
			      while (rs.next()) {
				        bddchamps test = new bddchamps(rs.getInt("userId"),rs.getInt("id"), rs.getString("title"), rs.getString("body"));
				        s = s  +" "+test.postText()+ "\n";
				      }
			      
			      rs.close();
			      reader.close();
	            
	        } catch (Exception e1) {
	            e1.printStackTrace();
	        }
		return s;
		
		} 
	}

